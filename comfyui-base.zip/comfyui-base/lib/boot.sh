#!/bin/bash
# boot.sh — the base's own boot on any host. Installed to <volume>/comfy-base/boot.sh; on RunPod podctl points the pod's
# start command at it, on a VM host the base's systemd unit runs it (comfy-base-boot.service, 2.2.0). bash 3.2-clean
# (the Mac runs these functions in the suite). Never `set -e`: a boot that dies takes the machine with it, and the whole
# point of this file is that it always comes up reachable.
#
#     bash boot.sh                          the boot (sshd → JupyterLab → ComfyUI → app ports and ComfyUI's locked front → sleep infinity); BOOT_HOME=<volume>/comfy-base
#     bash boot.sh --print-sshd-bootstrap   the self-contained sshd snippet podctl puts in a RunPod start command
#     bash boot.sh --apps                   (re)start the app ports only (3.9.0; the install runs it)
#
# BOOT_HOME defaults to this file's own directory (the image's ENV or the unit sets it explicitly). BOOT_ROOT prefixes
# /root and /run for the suite's fake pods; empty on a machine. BASE_LISTEN is 0.0.0.0 on RunPod and 127.0.0.1 elsewhere.

_boot_sshd_bin(){ # sshd on PATH; on a pod (no BOOT_ROOT) also the usual /usr/sbin/sshd, which is off PATH in some images
  command -v sshd 2>/dev/null && return 0
  if [ -z "${BOOT_ROOT:-}" ] && [ -x /usr/sbin/sshd ]; then echo /usr/sbin/sshd; return 0; fi
  return 1
}
boot_sshd(){ # authorized_keys from $PUBLIC_KEY, openssh-server when the image has none, sshd on 22 (keys only). Idempotent.
  # 2.1.0: no key, no sshd. A customer's pod from the public template has no PUBLIC_KEY (the toggle that sets it exists
  # only on RunPod's official templates), and a listener nobody can log in to is a port with no purpose.
  local root="${BOOT_ROOT:-}" sshd key="${PUBLIC_KEY:-}"
  if [ -z "$key" ]; then echo "boot: PUBLIC_KEY is empty — sshd not started (set PUBLIC_KEY on the pod to enable ssh)"; return 0; fi
  mkdir -p "$root/root/.ssh" && chmod 700 "$root/root/.ssh"
  printf '%s\n' "$key" > "$root/root/.ssh/authorized_keys" && chmod 600 "$root/root/.ssh/authorized_keys"
  if ! _boot_sshd_bin >/dev/null; then
    echo "boot: installing openssh-server"
    (apt-get update -qq && DEBIAN_FRONTEND=noninteractive apt-get install -y -qq openssh-server) >/dev/null 2>&1 || echo "boot: apt could not install openssh-server"
  fi
  mkdir -p "$root/run/sshd"
  ssh-keygen -A >/dev/null 2>&1 || true
  if pgrep -x sshd >/dev/null 2>&1; then echo "boot: sshd already running"; return 0; fi
  sshd="$(_boot_sshd_bin)" || { echo "boot: no sshd binary — the pod is reachable through JupyterLab only"; return 0; }
  if "$sshd" -p 22 -o PasswordAuthentication=no -o PermitRootLogin=prohibit-password; then echo "boot: sshd up on 22"
  else echo "boot: sshd did not start"; fi
  return 0
}

boot_tcmalloc(){ # the allocator the images preload; harmless when absent
  local so; so="$(ldconfig -p 2>/dev/null | grep -o 'libtcmalloc[^ ]*so[^ ]*' | head -1 || true)"
  [ -n "$so" ] && export LD_PRELOAD="$so" || true
}
boot_launch_lib(){ # 85-launch.sh: on the pod beside boot.sh's lib/, in the suite beside boot.sh itself
  local d here; here="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
  for d in "$BOOT_HOME/lib" "$here" "$here/lib"; do
    if [ -f "$d/85-launch.sh" ]; then
      if [ -f "$d/84-run-local.sh" ]; then . "$d/84-run-local.sh"; fi     # 3.15.0: the copy on the machine's own disk
      . "$d/85-launch.sh"; return 0
    fi
  done
  echo "boot: 85-launch.sh not found (looked in $BOOT_HOME/lib and beside boot.sh) — not starting ComfyUI"; return 1
}
boot_host(){ # 2.2.0: which host this is and where it may listen. RunPod's own variable, else the driver's state/host.env, else a VM.
  local f="$BOOT_HOME/state/host.env" h=""
  if [ -f "$f" ]; then h="$(sed -n 's/^BASE_HOST=//p' "$f" | head -1)"; fi
  if [ -n "${RUNPOD_POD_ID:-}" ]; then h=runpod; fi
  BASE_HOST="${BASE_HOST:-${h:-vm}}"
  if [ -z "${BASE_LISTEN:-}" ]; then if [ "$BASE_HOST" = runpod ]; then BASE_LISTEN=0.0.0.0; else BASE_LISTEN=127.0.0.1; fi; fi
  BOOT_VOLUME="$(dirname "$BOOT_HOME")"
  # 2.4.0: the shared library, so the machine's own boot starts ComfyUI on the same output/ and input/ the
  # install pointed it at. The unit RequiresMountsFor it, so by here it is mounted or the server never ran.
  if [ -z "${BASE_LIBRARY:-}" ] && [ -f "$f" ]; then BASE_LIBRARY="$(sed -n 's/^BASE_LIBRARY=//p' "$f" | head -1)"; fi
  BASE_LIBRARY="${BASE_LIBRARY%/}"
  if [ -n "${BASE_LIBRARY:-}" ] && [ ! -d "$BASE_LIBRARY" ]; then
    echo "boot: BASE_LIBRARY=$BASE_LIBRARY is not a directory, starting WITHOUT the shared library"
    BASE_LIBRARY=""
  fi
  export BASE_HOST BASE_LISTEN BASE_LIBRARY
  export DO_NOT_TRACK=1 COMFY_NO_TELEMETRY=1   # comfy-cli ships mixpanel and posthog; rule 9 says nothing is uploaded
  echo "boot: host $BASE_HOST · listen $BASE_LISTEN · volume $BOOT_VOLUME · library ${BASE_LIBRARY:-none}"
}
boot_extensions(){ # 2.2.0: a project's own boot stages, ext/*.sh, sourced in name order. Looked for on the volume first, then beside
  # this very file: on a baked image's FIRST boot the volume is empty and the seed's own ext/ (beside the seed's boot.sh) is the
  # copy that has to run, because copying the seed onto the volume is what such an extension does. The base ships no extension.
  local d f n=0 here; here="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
  for d in "$BOOT_HOME/ext" "$here/ext"; do
    [ -d "$d" ] || continue
    for f in "$d"/*.sh; do
      [ -f "$f" ] || continue
      echo "boot: extension $f"; . "$f"; n=$((n+1))
    done
    if [ "$n" -gt 0 ]; then break; fi
  done
  [ "$n" -gt 0 ] || echo "boot: no extensions (no ext/*.sh on the volume or beside boot.sh)"
  return 0
}
boot_jupyter(){ # JupyterLab from the base's tools venv; the token rides the environment (never argv); never tokenless
  # 2.1.0: the tokenless start is gone: an unauthenticated JupyterLab on a *.proxy.runpod.net URL is root on the box.
  # 3.9.0: and it is never dark for want of a token either. A pod's own JUPYTER_TOKEN (podctl create sets a fresh one per
  # pod) or JUPYTER_PASSWORD wins; else the one saved in state/tokens.env; else one is GENERATED and saved, on every bind.
  # 2.5.6 generated only on loopback and 2.1.0 refused the public bind, because nobody had anywhere to read a generated
  # token. Now somebody does: podctl status, jupyter and tunnel read it over ssh, and on RunPod's public bind the boot
  # writes ONE line naming it to the CONTAINER log (RunPod's Logs tab, the pod owner's), which is how a pod from the
  # public template, with no ssh key, gets its terminal. Never to the boot log, which is a file on the volume.
  # 3.19.1 (Paul, 2026-10-17: "can you fix this so I can click the links?"): on a public bind the terminal is OPEN unless
  # the pod opts into the lock (BASE_LINK_LOCK=1, boot_link_locked). RunPod's proxy passes nothing that names the pod's
  # owner, so any login is one more step on the Connect tab's link, and the order is speed, simplicity, privacy, then
  # security that costs no step. A loopback bind (a --private pod, a VM, reached through the tunnel) keeps its token:
  # the tunnel's link carries it, so it costs no click there.
  local jl="$BOOT_HOME/tools/bin/jupyter-lab" tok="${JUPYTER_TOKEN:-${JUPYTER_PASSWORD:-}}" made="" own=1
  local listen="${BASE_LISTEN:-127.0.0.1}"
  if [ ! -x "$jl" ]; then echo "boot: no JupyterLab in $BOOT_HOME/tools (the base install builds it) — port 8888 stays dark"; return 0; fi
  # an operator's own JUPYTER_PASSWORD (podctl never sets one) is a choice they made, and is kept
  if boot_public && ! boot_link_locked && [ -z "${JUPYTER_PASSWORD:-}" ]; then
    mkdir -p "$BOOT_HOME/state/logs"
    env -u JUPYTER_TOKEN -u JUPYTER_PASSWORD nohup "$jl" --ip "$listen" --port 8888 --allow-root --no-browser --ServerApp.allow_origin='*' \
      --IdentityProvider.token= --notebook-dir "${BOOT_VOLUME:-$(dirname "$BOOT_HOME")}" >> "$BOOT_HOME/state/logs/jupyter.log" 2>&1 &
    echo "boot: JupyterLab starting on 8888 (the Jupyter Terminal, bound to $listen, open: its Connect link needs no token; BASE_LINK_LOCK=1 locks it)"
    return 0
  fi
  # read the saved one FIRST, so this does not depend on boot_tokens having run: a second boot must reuse the
  # token, never append a new line. My own test caught it doing exactly that.
  local tf="$BOOT_HOME/state/tokens.env"
  if [ -z "$tok" ]; then tok="$(boot_pid1_env JUPYTER_TOKEN)"; fi       # 3.14.0: `boot.sh --apps` from an install's ssh shell
  if [ -n "$tok" ]; then own=0; fi
  if [ -z "$tok" ] && [ -f "$tf" ]; then tok="$(sed -n 's/^JUPYTER_TOKEN=//p' "$tf" | tail -1)"; fi
  if [ -z "$tok" ]; then
    tok="$( (openssl rand -hex 32 2>/dev/null) || (head -c32 /dev/urandom | od -An -tx1 | tr -d " \n") )"
    if [ -z "$tok" ]; then echo "boot: JupyterLab not started — no token could be generated and none was set (never tokenless)"; return 0; fi
    mkdir -p "$BOOT_HOME/state"; ( umask 077; printf 'JUPYTER_TOKEN=%s\n' "$tok" >> "$tf" )
    chmod 600 "$tf" 2>/dev/null || true
    made=" (token generated, saved to state/tokens.env)"
  fi
  export JUPYTER_TOKEN="$tok"
  mkdir -p "$BOOT_HOME/state/logs"
  JUPYTER_TOKEN="$tok" nohup "$jl" --ip "$listen" --port 8888 --allow-root --no-browser --ServerApp.allow_origin='*' --notebook-dir "${BOOT_VOLUME:-$(dirname "$BOOT_HOME")}" >> "$BOOT_HOME/state/logs/jupyter.log" 2>&1 &
  echo "boot: JupyterLab starting on 8888 (the Jupyter Terminal, bound to $listen)$made"
  # The token is NEVER echoed here. This log is a file on the volume, and with a shared store that volume is mounted
  # by every machine and readable by every session on it; the suite has forbidden logging an operator-supplied token
  # since 2.1.0 and a generated one is the same secret. What goes in the log is how to GET it.
  case "$listen" in
    127.0.0.1|localhost|::1|'')
      local ip; ip="$(hostname -I 2>/dev/null | awk '{print $1}')"
      echo "boot: to use the terminal and upload files, from YOUR OWN computer run:"
      echo "boot:     podctl jupyter <this machine>     # prints the URL with the token already in it"
      echo "boot:     podctl tunnel <this machine>      # the one tunnel; prints every named link, the terminal's with its token"
      echo "boot:   or by hand:  ssh -L 8888:127.0.0.1:8888 root@${ip:-THE-MACHINE-IP}"
      echo "boot:     then open http://127.0.0.1:8888/lab and paste the token from state/tokens.env (owner-only)"
      ;;
    *)
      echo "boot: the token: podctl status <pod> prints the link with it; on RunPod also the pod's Logs tab (not this file)"
      boot_console_token "$tok" "$own"
      ;;
  esac
  return 0
}
boot_console_token(){ # <token> <own: 1 = generated or saved, 0 = the pod's own env> → one line on the CONTAINER log, RunPod only
  # fd 3 is the start command's own stdout, saved by boot_main before it sends everything else to the boot log. On RunPod
  # that is the pod's Logs tab, which only the pod's owner reads; the boot log is a file on a volume others may mount.
  # A token the pod's env set is the operator's own and is not repeated; one the boot made is the only copy they can see.
  [ "${2:-1}" = 1 ] || return 0
  [ "${BASE_HOST:-}" = runpod ] || return 0
  { true >&3; } 2>/dev/null || return 0
  local url=""
  if [ -n "${RUNPOD_POD_ID:-}" ]; then url="https://${RUNPOD_POD_ID}-8888.proxy.runpod.net/lab?token=$1"; fi
  echo "Jupyter Terminal token: $1${url:+   (open $url)}" >&3
  return 0
}
boot_tokens(){ # 2.1.0: the tokens an earlier install saved (state/tokens.env, 0600) join the pod's own; the Hub browser
  # pack reads its own name. Values are exported, never echoed. 20-comfyui.sh's _base_tokens_export_buttons is the
  # install-time twin; boot.sh sources none of lib/[0-9]* so it carries its own lines.
  local f="$BOOT_HOME/state/tokens.env" name val n=0
  # 3.19.0: a RunPod Secret reference RunPod could not resolve (the account has no secret of that name) reaches the pod
  # as the literal "{{ RUNPOD_SECRET_<NAME> }}". It is a placeholder, never a token: unset, so a saved one applies and
  # nothing hands the literal to the Hub as a bearer token. The same rule as 20-comfyui.sh's _base_token_is_placeholder.
  local ph=""
  for name in HF_TOKEN HUGGING_FACE_HUB_TOKEN HF_HUB_TOKEN CIVITAI_TOKEN CIVITAI_API_KEY CIVITAI_API_TOKEN; do
    case "${!name:-}" in "{{"*) unset "$name"; ph="$ph $name";; esac
  done
  [ -z "$ph" ] || echo "boot: unresolved RunPod Secret references ignored (placeholders, not tokens):$ph"
  if [ -f "$f" ]; then
    while IFS='=' read -r name val; do
      [[ "$name" =~ ^[A-Z_]+$ ]] || continue
      if [ -z "${!name:-}" ] && [ -n "$val" ]; then export "$name=$val"; n=$((n+1)); fi   # the pod's own value wins over a saved one
    done < "$f"
  fi
  local names=""
  if [ -n "${HF_TOKEN:-}" ]; then export HUGGINGFACE_API_KEY="$HF_TOKEN"; names="HUGGINGFACE_API_KEY"; fi
  echo "boot: tokens — $n loaded from state/tokens.env; exported for the download buttons: ${names:-(none)}"
  return 0
}
boot_prewarm(){ # 3.15.0: the copy of ComfyUI's code to this machine's disk starts NOW, in the background, beside sshd,
  # JupyterLab and the extensions; boot_comfy then waits for it on its lock and finds it current. In a subshell: boot.env's
  # names are boot_comfy's to set. No boot.env yet (a fresh volume): nothing to copy.
  local f="$BOOT_HOME/state/boot.env"
  [ -f "$f" ] || return 0
  ( . "$f"; PY="$VENV/bin/python"
    boot_launch_lib >/dev/null || exit 0
    if declare -F _base_run_prewarm >/dev/null; then _base_run_prewarm | sed 's/^ */boot: /'; fi )
  return 0
}
boot_comfy(){ # ComfyUI from the base's venv with the base's launch line, only when that venv can boot
  local f="$BOOT_HOME/state/boot.env"
  if [ ! -f "$f" ]; then echo "boot: no $f — the base has not installed ComfyUI on this volume yet; nothing to start"; return 0; fi
  . "$f"
  PY="$VENV/bin/python"; HOSTPORT="127.0.0.1:$PORT"; COMFY_LOG="$BOOT_HOME/state/logs/comfyui.log"
  BASE_STATE="$BOOT_HOME/state"             # 3.20.0: the boot's state is its own (servers.list, pid files), never an inherited one
  BASE_PERSIST_ROOT="${PERSIST:-}"; BASE_PREVIEW_SIZE="${PREVIEW_SIZE:-1024}"; ARGS_IMPORT=""
  if [ ! -x "$PY" ]; then echo "boot: $PY is missing — not starting ComfyUI. Fix: bash '<package>-script.sh' rescue"; return 0; fi
  boot_launch_lib || return 0
  # 3.15.0: the copy on this machine's disk first. Its python has just imported torch (run_local.py checks it before the
  # copy is used), so the volume's own torch import, a minute or more over a network volume, is asked only without one.
  RUN_HERE_PY="$PY"; if declare -F _base_run_here >/dev/null; then echo "boot: ComfyUI's code to this machine's disk"; _base_run_here; fi
  if [ "$RUN_HERE_PY" = "$PY" ] && ! "$PY" -c 'import torch' >/dev/null 2>&1; then echo "boot: $VENV cannot import torch — not starting ComfyUI. Fix: bash '<package>-script.sh' rescue, or re-run a package script"; return 0; fi
  if command -v nvidia-smi >/dev/null 2>&1 && command -v python3 >/dev/null 2>&1 && [ -f "$BOOT_HOME/py/gpu_facts.py" ]; then
    echo "boot: gpu $(python3 "$BOOT_HOME/py/gpu_facts.py" 2>/dev/null || echo 'unreadable')"     # NOT-OURS here = memory held outside this container: stop/start or redeploy (2.0.26)
  fi
  # 3.0.3: this boot has started nothing yet, so any ComfyUI running now is one it does not own: an earlier install's
  # detached start, outside the unit. Left running, it keeps the port and its VRAM and this boot's server is the second
  # GPU process beside it (MEASURED on a Verda machine: two main.py after `systemctl restart comfy-base-boot`).
  if [ -n "$(_base_comfy_pids 2>/dev/null || true)" ]; then
    echo "boot: a ComfyUI this boot did not start is running: stopping it first (one ComfyUI per GPU, all started by the boot)"
    if ! _base_stop_comfy; then echo "boot: it would not stop, so no second ComfyUI is started beside it"; return 0; fi
  fi
  echo "boot: starting ComfyUI: $(_base_start_cmd)"
  # 3.20.0: one server per GPU (85-launch.sh), each named on its own line; server 0 on $HOSTPORT is the verdict here
  if _base_start_comfy; then echo "boot: ComfyUI answers on $HOSTPORT"; else echo "boot: ComfyUI did not answer within the wait — see $COMFY_LOG"; fi
  return 0
}
boot_pid1_env(){ # <NAME> → the pod's own environment (PID 1's): `boot.sh --apps` runs from an install's ssh shell, which does not inherit it
  local f="${BOOT_PID1_ENVIRON:-/proc/1/environ}"
  [ -z "${BOOT_ROOT:-}" ] || [ -n "${BOOT_PID1_ENVIRON:-}" ] || return 0     # a fake pod never reads the host's PID 1
  [ -r "$f" ] && tr '\0' '\n' < "$f" 2>/dev/null | sed -n "s/^$1=//p" | head -1
  return 0
}
boot_link_locked(){ # 3.19.1: 0 when the pod opted into the key (BASE_LINK_LOCK=1: its env, else PID 1's); links are open otherwise
  local v="${BASE_LINK_LOCK:-}"
  [ -n "$v" ] || v="$(boot_pid1_env BASE_LINK_LOCK)"
  [ "$v" = 1 ]
}
boot_public(){ # 0 when BASE_LISTEN reaches beyond the machine (the key is then required on every link)
  case "${BASE_LISTEN:-127.0.0.1}" in 127.*|localhost|::1|'') return 1 ;; *) return 0 ;; esac
}
boot_link_token(){ # 3.14.0: the key that locks ComfyUI and every app link on a public bind (py/app_proxy.py checks it)
  # The pod's own BASE_LINK_TOKEN (podctl create sets a fresh one per pod and prints the links with it) wins, read from
  # PID 1 when this shell did not inherit it; else the one saved in state/tokens.env; else, on a public bind, one is
  # GENERATED and saved (0600), exactly as JupyterLab's is. Exported for the forwarder alone; never echoed here (this log is
  # a file on the volume). BOOT_LINK_MADE=1 when this call made it: boot_apps then names the links once on the CONTAINER log.
  # 3.30.0: BASE_LINK_TOKEN_FROM=<NAME> (the pod's env, else PID 1's) makes the key the value of the variable NAME, which the
  # customer already has (the template's own key): nothing is generated, saved or printed, and the forwarder's lock page asks
  # for it (BOOT_LINK_FROM=1). NAME is exported beside it so the forwarder inherits the value; NAME missing, malformed or
  # empty falls through to the rules below.
  local tf="$BOOT_HOME/state/tokens.env" tok="${BASE_LINK_TOKEN:-}" from="${BASE_LINK_TOKEN_FROM:-}" fv=""
  BOOT_LINK_MADE=0; BOOT_LINK_FROM=0
  [ -n "$from" ] || from="$(boot_pid1_env BASE_LINK_TOKEN_FROM)"
  case "$from" in ''|[0-9]*|*[!A-Za-z0-9_]*) from="" ;; esac
  if [ -n "$from" ]; then
    fv="${!from:-}"; [ -n "$fv" ] || fv="$(boot_pid1_env "$from")"
    if [ -n "$fv" ]; then export BASE_LINK_TOKEN_FROM="$from"; export "$from=$fv"; BOOT_LINK_FROM=1; return 0; fi
    echo "boot: BASE_LINK_TOKEN_FROM=$from, but $from is empty: the key is made the usual way"
  fi
  [ -n "$tok" ] || tok="$(boot_pid1_env BASE_LINK_TOKEN)"
  if [ -z "$tok" ] && [ -f "$tf" ]; then tok="$(sed -n 's/^BASE_LINK_TOKEN=//p' "$tf" | tail -1)"; fi
  if [ -z "$tok" ] && boot_public; then
    tok="$( (openssl rand -hex 32 2>/dev/null) || (head -c32 /dev/urandom | od -An -tx1 | tr -d " \n") )"
    if [ -n "$tok" ]; then
      mkdir -p "$BOOT_HOME/state"; ( umask 077; printf 'BASE_LINK_TOKEN=%s\n' "$tok" >> "$tf" ); chmod 600 "$tf" 2>/dev/null || true
      BOOT_LINK_MADE=1
    fi
  fi
  if [ -n "$tok" ]; then export BASE_LINK_TOKEN="$tok"; fi
  return 0
}
boot_console_links(){ # <comfy port> <rows> → one line per locked link on the CONTAINER log (RunPod's Logs tab), only for a key the boot made
  # 3.30.0: a key from the environment (BOOT_LINK_FROM=1) is the customer's own and is never printed: one line says where it goes
  if [ "${BOOT_LINK_FROM:-0}" = 1 ] && [ "${BASE_HOST:-}" = runpod ] && { true >&3; } 2>/dev/null; then
    echo "The links ask for your key (${BASE_LINK_TOKEN_FROM}): open ComfyUI from the Connect tab and type it once." >&3
  fi
  [ "${BOOT_LINK_MADE:-0}" = 1 ] && [ "${BASE_HOST:-}" = runpod ] && [ -n "${RUNPOD_POD_ID:-}" ] && [ -n "${BASE_LINK_TOKEN:-}" ] || return 0
  { true >&3; } 2>/dev/null || return 0
  local p s nm
  echo "ComfyUI: https://${RUNPOD_POD_ID}-$1.proxy.runpod.net/?token=${BASE_LINK_TOKEN}" >&3
  printf '%s\n' "$2" | while IFS='|' read -r p s nm; do
    case "$p" in [0-9]*) echo "$nm: https://${RUNPOD_POD_ID}-$p.proxy.runpod.net/?token=${BASE_LINK_TOKEN}" >&3 ;; esac
  done
  return 0
}
boot_apps_py(){ # the Python the forwarder runs on: the tools venv's, else the machine's python3 (standard library only)
  if [ -x "$BOOT_HOME/tools/bin/python" ]; then echo "$BOOT_HOME/tools/bin/python"; return 0; fi
  command -v python3 2>/dev/null && return 0
  return 1
}
boot_apps_stop(){ # every forwarder THIS volume's boot started on this machine (matched by its own path, so a shared store's
  # other machines, and anything else that happens to be a python, are never touched)
  local pids i
  pids="$(pgrep -f "app_proxy\.py --state $BOOT_HOME/state" 2>/dev/null | tr '\n' ' ' || true)"; pids="${pids% }"
  [ -n "$pids" ] || return 0
  kill $pids 2>/dev/null || true
  for i in 1 2 3 4 5; do
    sleep 1; [ -n "$(pgrep -f "app_proxy\.py --state $BOOT_HOME/state" 2>/dev/null || true)" ] || return 0
  done
  kill -9 $pids 2>/dev/null || true
  return 0
}
boot_apps(){ # 3.9.0: each customer app at the root of its own port (state/apps.d/*.list, one file per package's APP_PORTS)
  # A host whose console links PORTS, not paths (RunPod's Connect tab), can only name an app that has a port of its own;
  # ComfyUI serves the app at /apps/<slug>/ and py/app_proxy.py forwards <port>/ there. Restarted on every call, so an
  # install that adds or drops an app takes effect at once (boot.sh --apps). Not on the GPU: it only moves bytes.
  # 3.14.0: on a public bind the same process is ComfyUI's front too (--front: ComfyUI's port on the machine's other
  # addresses, ComfyUI itself on 127.0.0.1), and every link it serves needs the key (boot_link_token). So on a public
  # bind it runs even when no package declares an app: without it ComfyUI would not be reachable from outside at all.
  local py proxy="$BOOT_HOME/py/app_proxy.py" port="${PORT:-}" rows n front=() opn=()
  if [ -z "$port" ] && [ -f "$BOOT_HOME/state/boot.env" ]; then port="$(sed -n "s/^PORT='\{0,1\}\([0-9]*\).*/\1/p" "$BOOT_HOME/state/boot.env" | head -1)"; fi
  port="${port:-8188}"
  boot_apps_stop
  if [ ! -f "$proxy" ]; then echo "boot: no $proxy, so no app ports and no front for ComfyUI (the base install puts it there)"; return 0; fi
  if ! py="$(boot_apps_py)"; then echo "boot: no python for the app ports: none started"; return 0; fi
  rows="$("$py" "$proxy" --state "$BOOT_HOME/state" --list 2>&1)" || { echo "boot: app ports unreadable: $rows"; return 0; }
  n="$(printf '%s\n' "$rows" | grep -c '^[0-9]' || true)"
  if boot_public; then
    if [ -n "${BOOT_FRONT_LISTEN:-}" ]; then front=(--front "$port" --front-listen "$BOOT_FRONT_LISTEN")   # the suite's stand-in for the machine's addresses
    elif [ -z "${BOOT_ROOT:-}" ]; then front=(--front "$port")
    else echo "boot: a fake pod (BOOT_ROOT): ComfyUI's front is not started on this machine's own addresses"; fi
    # 3.19.1: the key only when the pod opted in; otherwise every link opens on one click (--open)
    if boot_link_locked; then if [ "${#front[@]}" -gt 0 ]; then boot_link_token; fi; else opn=(--open); fi
  fi
  if [ "${n:-0}" = 0 ] && [ "${#front[@]}" = 0 ]; then echo "boot: app ports: none declared (no package ships a customer app)"; return 0; fi
  mkdir -p "$BOOT_HOME/state/logs"
  nohup "$py" "$proxy" --state "$BOOT_HOME/state" --upstream "127.0.0.1:$port" --listen "${BASE_LISTEN:-127.0.0.1}" ${front[@]+"${front[@]}"} ${opn[@]+"${opn[@]}"} >> "$BOOT_HOME/state/logs/app_proxy.log" 2>&1 &
  if [ "${#front[@]}" -gt 0 ]; then
    echo "boot: ComfyUI's port $port: $(boot_link_locked && echo "the key's front" || echo "the front, open (BASE_LINK_LOCK=1 locks it)") on this machine's addresses (ComfyUI itself on 127.0.0.1)$( [ "${BOOT_LINK_MADE:-0}" = 1 ] && echo ' · key generated, saved to state/tokens.env')$( [ "${BOOT_LINK_FROM:-0}" = 1 ] && echo " · the key is \$${BASE_LINK_TOKEN_FROM}'s value, asked for on the lock page")"
  fi
  if [ "${n:-0}" = 0 ]; then echo "boot: app ports: none declared (no package ships a customer app)"; fi
  printf '%s\n' "$rows" | while IFS='|' read -r p s nm; do
    case "$p" in [0-9]*) echo "boot: app port $p: $nm (/apps/$s/ on ComfyUI's $port)";; *) echo "boot: $p";; esac
  done
  boot_console_links "$port" "$rows"
  return 0
}
boot_main(){
  case "${1:-}" in
    --print-sshd-bootstrap) declare -f _boot_sshd_bin; declare -f boot_sshd; echo "boot_sshd"; return 0 ;;
    --apps)                                        # 3.9.0: the install restarts the app ports without a reboot
      BOOT_HOME="${BOOT_HOME:-$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)}"
      boot_host >/dev/null; boot_apps
      # 3.14.0: a pod podctl creates runs nothing of its image's own (provider.create_start), so until its first restart into
      # this boot there is no JupyterLab either: the install starts it here, once its tools venv exists, with the pod's token
      if [ -x "$BOOT_HOME/tools/bin/jupyter-lab" ] && ! pgrep -f "jupyter-lab .*--port 8888" >/dev/null 2>&1; then boot_jupyter; fi
      return 0 ;;
  esac
  BOOT_HOME="${BOOT_HOME:-$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)}"   # the image's ENV or the unit sets it; this file's own directory otherwise
  mkdir -p "$BOOT_HOME/state/logs"
  echo $$ > "$BOOT_HOME/state/boot.pid"        # the pod tier tells a base boot from the image's by this pid's cmdline (2.0.6)
  BOOT_LOG="$BOOT_HOME/state/logs/boot_$(date +%Y%m%d-%H%M%S).log"
  exec 3>&1                                    # 3.9.0: the start command's own stdout (RunPod's Logs tab), for boot_console_token
  exec >> "$BOOT_LOG" 2>&1
  trap 'exit 0' TERM
  echo "== comfy-base boot $(date -u +%Y-%m-%dT%H:%M:%SZ) · $(hostname 2>/dev/null || echo ?) =="
  boot_tcmalloc
  boot_host
  boot_prewarm
  boot_sshd
  boot_jupyter
  boot_tokens
  boot_extensions
  boot_comfy
  boot_apps
  echo "boot: done — sleeping forever so the pod stays up (this script never exits on its own)"
  if [ "${BOOT_ONCE:-0}" = "1" ]; then return 0; fi
  sleep infinity
}

if [ "${BASH_SOURCE[0]}" = "$0" ]; then boot_main "$@"; fi
